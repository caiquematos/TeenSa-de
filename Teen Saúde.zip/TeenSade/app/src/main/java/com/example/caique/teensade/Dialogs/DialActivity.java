package com.example.caique.teensade.Dialogs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.example.caique.teensade.R;

public class DialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dial);
    }
}